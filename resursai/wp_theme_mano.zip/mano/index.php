
	<?php get_header(); ?>



			<?php
			// meniu atsiras cia                   !!!! primary_pagrindinis - turi sutapti pavadinimas su funcitons.php faile aprasytu
			wp_nav_menu( array('theme_location' => 'primaryPagrindinis'));
			?>

			<h1>Mano tema yra</h1>

			<?php
//			query_posts( 'posts_per_page=2' ); // paims tik 2 post !jeigu bansysi uzkrauti konkretu page, numusa

			if(have_posts()) :
				while(have_posts()) :
					the_post();
					?>

					 <h2> <?php the_title(); ?>  </h2>
					 <p>  <?php   the_content();  ?> </p>
					 <p>   <?php the_time(); ?> </p>

				<?php
				endwhile;
			endif;
			?>


	<?php get_footer(); ?>

