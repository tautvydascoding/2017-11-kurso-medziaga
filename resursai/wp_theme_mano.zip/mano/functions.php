<?php




// CSS ir JS mano failu idejimas i mano theme'a
function failuParuosimas() {

	// 				  my name            path to css file							 dependencies version  @media kur naudoti
	wp_enqueue_style('customstyle', get_template_directory_uri() . '/css/custom.css', array(),    '1.0.0',   'all');
	// 				  my name            path to css file							 dependencies version     ar footer
	wp_enqueue_script('customscript', get_template_directory_uri() . '/js/custom.js', array(),    '1.0.0',   'true');
}

// kada paleisti musu f-ja "ready_files" ? 
add_action('wp_enqueue_scripts', failuParuosimas);


// Menu
function menuParuosimas() {
	add_theme_support('menus');
	//                  Menu Name                  Description
	register_nav_menu('primaryPagrindinis', 'Meniu atvaizduojamas virsuje psulapio'); // atsiras Appearance->menu  checkbox - Theme Location
}
add_action('after_setup_theme', 'menuParuosimas');




add_theme_support('custom-background');
add_theme_support('custom-header');
add_theme_support('post-thumbnails'); // ijungia Featured images

add_theme_support('post-formats', array('aside', 'image', 'video', 'gallery'));

//





/*
 * Helper function to return the theme option value. If no value has been saved, it returns $default.
 * Needed because options are saved as serialized strings.
 * This code allows the theme to work without errors if the Options Framework plugin has been disabled.
 */
if ( !function_exists( 'of_get_option' ) ) {
    function of_get_option($name, $default = false) {
        $optionsframework_settings = get_option('optionsframework');
        // Gets the unique option id
        $option_name = $optionsframework_settings['id'];
        if ( get_option($option_name) ) {
            $options = get_option($option_name);
        }
        if ( isset($options[$name]) ) {
            return $options[$name];
        } else {
            return $default;
        }
    }
}

